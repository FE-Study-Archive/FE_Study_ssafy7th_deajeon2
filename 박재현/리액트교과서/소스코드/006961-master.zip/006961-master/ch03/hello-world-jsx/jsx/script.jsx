// var helloWorldReactElement = <h1>Hello world!</h1>
// ReactDOM.render(
//   helloWorldReactElement,
//   document.getElementById('content')
// )

ReactDOM.render(
  <h1>Hello world!</h1>,
  document.getElementById('content')
)