const DigitalDisplay = function (props) {
  return React.createElement(
    "div",
    null,
    props.time
  );
};