ReactDOM.render(React.createElement(
  'div',
  null,
  React.createElement(Content, null)
), document.getElementById('content'));