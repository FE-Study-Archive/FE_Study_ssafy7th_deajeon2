ReactDOM.render(
  <div>
    <AddSub defaultValue={50}/>
  </div>,
  document.getElementById('content')
)
