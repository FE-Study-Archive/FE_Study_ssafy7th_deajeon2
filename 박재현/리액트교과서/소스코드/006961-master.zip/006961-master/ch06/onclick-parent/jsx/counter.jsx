class Counter extends React.Component {
  render() {
    return <span>Clicked {this.props.value} times.</span>
  }
}