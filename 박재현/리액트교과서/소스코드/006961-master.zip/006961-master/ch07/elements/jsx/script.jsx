ReactDOM.render(
  <Content data-url="http://webapplog.com" />,
  document.getElementById('content')
)
