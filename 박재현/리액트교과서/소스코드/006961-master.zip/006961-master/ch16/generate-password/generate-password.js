module.exports = () => (
    Math.random().toString(36).slice(-8)
)
