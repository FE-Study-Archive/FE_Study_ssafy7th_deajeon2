var generatePassword = require('./generate-password.js')
console.log(generatePassword())
console.log(generatePassword())
