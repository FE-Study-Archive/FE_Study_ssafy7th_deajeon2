To run the project (you need MongoDB as well- `$ mongod`):

```
$ npm install -g gulp
$ npm install
$ gulp
```

Open at <localhost:3000>

* Dependencies (node_modules) are included.
