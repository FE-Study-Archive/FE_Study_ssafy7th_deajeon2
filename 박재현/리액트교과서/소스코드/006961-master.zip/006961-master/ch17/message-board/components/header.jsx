const React = require('react')
const Header = ()=>{
  return (
    <h1>Message Board</h1>
  )
}

module.exports = Header

